<?php
	switch($server['s']['game']){
		case "tf":
			switch($type){
				case "small":
					$txt_outline = true;
					$text_color0 = ImageColorAllocate($im, 255, 149, 56);
				break;
				case "normal":
					$txt_outline = false;
					$text_color0 = ImageColorAllocate($im, 255, 149, 56);
				break;
				case "sky":
					$txt_outline = true;
					$text_color1 = ImageColorAllocate($im, 255, 149, 56);
				break;
			}
		break;
	}
?>