<?php

                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TheWar.ro - Licente Steam Counter Strike 1.6, Counter Strike Source si alte jocuri!</title>
<style type="text/css">
@import url(http://thewar.ro/css.css);
</style>
<script type="text/javascript"></script><link rel='stylesheet' type='text/css' href='/B1D671CF-E532-4481-99AA-19F420D90332/netdefender/hui/ndhui.css' /></head>
<body>
    <div id="wrapper">
    <center><img src="images/logo.png" /></center>
    <ul id="nav">
        <li><a href="index.php">Prima pagina</a></li>
        <li><a href="desprejoc.php">Despre joc</a></li>
        <li><a href="premii.php">Premii</a></li>
        <li><a href="castigatori.php">Castigatori</a></li>
        <li><a href="concurenti.php">Concurenti</a></li>
        <li><a href="inregistrare.php">Inregistrare</a></li>
        <li><a href="cont.php">Contul meu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div id="content"> 
<center>
<blink><font color='red'>Aboneaza-te</font> <font color=yellow>acum pe <a href='http://www.zambete.net'><font color=green>Zambete.NET</font></a> si primesti +30 scor in concurs!<br /></blink>Nu uita sa iti folosesti adresa de email din contul tau!</font><Br /><Br /><script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar Ads 1 */
google_ad_slot = "1832938061";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>   	
        <h2><center>Inregistrare</center></h2>
        <?php
        /*
Register processing
*/
include('config.php');


//Validare email
function check_email_address($email) {
        // First, we check that there's one @ symbol, and that the lengths are right
        if (!preg_match("/^[^@]{1,64}@[^@]{1,255}$/", $email)) {
            // Email invalid because wrong number of characters in one section, or wrong number of @ symbols.
            return false;
        }
        // Split it into sections to make life easier
        $email_array = explode("@", $email);
        $local_array = explode(".", $email_array[0]);
        for ($i = 0; $i < sizeof($local_array); $i++) {
            if (!preg_match("/^(([A-Za-z0-9!#$%&'*+\/=?^_`{|}~-][A-Za-z0-9!#$%&'*+\/=?^_`{|}~\.-]{0,63})|(\"[^(\\|\")]{0,62}\"))$/", $local_array[$i])) {
                return false;
            }
        }
        if (!preg_match("/^\[?[0-9\.]+\]?$/", $email_array[1])) { // Check if domain is IP. If not, it should be valid domain name
            $domain_array = explode(".", $email_array[1]);
            if (sizeof($domain_array) < 2) {
                return false; // Not enough parts to domain
            }
            for ($i = 0; $i < sizeof($domain_array); $i++) {
                if (!preg_match("/^(([A-Za-z0-9][A-Za-z0-9-]{0,61}[A-Za-z0-9])|([A-Za-z0-9]+))$/", $domain_array[$i])) {
                    return false;
                }
            }
        }

        return true;
    }


//Se verifica daca sunt transmise date
      if(isset($_POST['submit'])){
        
        foreach($_POST as $keypost => $postdata){
         
         mysql_real_escape_string($postdata);
         stripslashes($postdata);
         addslashes($postdata);

        }
        
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email    = $_POST['email'];
        

      $info = array();
        
        //Conditii si verificari
        if(isset($_POST['username'])){

               if(!ctype_alnum($_POST['username'])){

                  $info[] = 'Numele poate contine doar numere si litere!';
              
               }
           
               if(strlen($_POST['username']) > 8){
             
                  $info[] = 'Numele nu poate fi mai mare de 8 caractere!';
              
               }
        } else {
         
           $info[] = 'Campul nume nu poate fi gol!';

        }
        
       	
        if(isset($_POST['password'])){
		
                if($_POST['password'] != $_POST['passcheck']){
			
                        $info[] = 'Parolele nu se potrivesc!';
		}
	}
	else
	{
		$info[] = 'Campul parola nu poate fi gol!';
	}
	
	if(isset($_POST['email'])){
          
                if(!check_email_address($_POST['email'])){

                   $info[] = 'Adresa de mail nu este valida!';
                }
        } else {
         
                $info[] = 'Campul mail este gol!';

        }
        


        $premiu = $_POST['premiu'];
        $ip   = $_SERVER['REMOTE_ADDR']; //Ip utilizator
        
        $verificare_username = mysql_query("SELECT username FROM users WHERE username = '".mysql_real_escape_string($_POST['username'])."'") or die(mysql_error());
        $verificare_ip = mysql_query("SELECT ip FROM users WHERE ip = '$ip'") or die(mysql_error());
        $verificare_email = mysql_query("SELECT email FROM users WHERE email = '".mysql_real_escape_string($_POST['email'])."'") or die(mysql_error());


        if(mysql_num_rows($verificare_username) == 0) { // Verificare username

        if(mysql_num_rows($verificare_email) == 0) { // Verificare email
    
	     if(mysql_num_rows($verificare_ip) == 0) { // Verificare IP
	
		$insertdata = mysql_query("INSERT INTO users (id, username, password, email, frags, premiu, ip, status)
		VALUES ('', '$username', '$password', '$email', '0', '$premiu', '$ip', '1')");
		$info[] = "Contul a fost creat cu succes !<br><br>Go Go Go !<br><br>Link-ul tau: <input name='link' type='text' size='65' value='http://$siteurl/link.php?player=$username'/>";
			
			
			} else {
			
			$info[] = "A fost deja creat un cont de pe aceasta adresa ip !";
		}
	} else {
			$info[] = "Aceasta adresa de email este deja folosita !<br> Te rog sa alegi alta.";
	}
	
	} else {
	
	$info[] = "Acest username este deja folosit !<br> Te rog sa alegi altul.";
	}
	
	
	        if(!empty($info)){
        
print '<ul class="nostyle">';
  
          foreach($info as $key => $messages){
          
              print '<li>'.$messages.'</li>';

          }
print '</ul>';
        }

			
}
?>

<div align="center">
<br>         
<form action="" method="post">
<table>
<tr>
<td><font size="1pt">Nume:</font></td><td align="right"><input name="username" type="text" size="30" maxlength="20" id="rinput"  class="tbox" /></td>
</tr><tr>
<td><font size="1pt">Parola:</font></td><td align="right"><input name="password" type="password" size="30" maxlength="20" id="rinput" class="tbox" /></td>
</tr><tr>
<td><font size="1pt">Repeta Parola:</font></td><td align="right"><input name="passcheck" type="password" size="30" maxlength="20" id="rinput" class="tbox" /></td>
</tr><tr>
<td><font size="1pt">Email:</font></td><td align="right"><input name="email" type="text" size="30" maxlength="40" id="rinput" class="tbox" /></td>
</tr><tr>
<td><font size="1pt">Premiu:</font></td><td align="right"><input name="premiu" type="text" size="30" maxlength="40" id="rinput" class="tbox" /></td>
</tr><tr>
<td align="center" colspan="2">
<br>
<font size="2pt">Premii disponibile</font><br>

<img height="197" src="images/premii/1.png" width="139" />&nbsp;&nbsp;<img height="197" src="images/premii/2.png" width="139" /><br>
<img height="197" src="images/premii/3.png" width="139" />&nbsp;&nbsp;<img height="197" src="images/premii/6.png" width="139" /><br>
<img height="197" src="images/premii/7.png" width="139" />&nbsp;&nbsp;<img height="197" src="images/premii/9.png" width="139" /><br>

			
			<br>

<font size="1pt">Se accepta un singur cont / IP</font><br>
<br>


<input type="submit" name="submit" value="Inregistrare" id="rinput"></td>
</tr>
</table>
</form>
<br>
</div> 
    <br /><br />
        <center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0145581883123345";
/* thewar */
google_ad_slot = "7066114169";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center></div>
    <div id="foot"><br><center><script type="text/javascript" src="http://profitshare.emag.ro/get_ads.php?zone_id=112055"></script></center><br /><!--/ GTop.ro - (begin) v2.1/-->
<script type="text/javascript" language="javascript">
var site_id = 49092;
var gtopSiteIcon = 79;
var _gtUrl = (("https:" == document.location.protocol) ? "https://secure." : "http://fx.");
document.write(unescape("%3Cscript src='" + _gtUrl + "gtop.ro/js/gTOP.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--/ GTop.ro - (end) v2.1/--> <a href='http://www.gtasa.ro' target="_blank"><img src='parteneri/gtasa.jpg' /></a> <a href='http://www.hackernews.ro' target="_blank"><img src='parteneri/hackernews.jpg' /></a> <a href='http://www.imgz.ro' target="_blank"><img src='parteneri/imgz.jpg' /></a> <a href='http://www.romaniadescarca.ro' target="_blank"><img src='parteneri/romaniadescarca.jpg' /></a> <a href='http://www.rss-ro.com' target="_blank"><img src='parteneri/rss.jpg' /></a> <a href='http://www.zambete.net' target="_blank"><img src='parteneri/zambete.jpg' /></a><br />&copy TheWar.ro<br />

<!--/* Ad4Game Popunder Tag */-->

<script type='text/javascript' src='http://ads.ad4game.com/www/delivery/apu.php?n=&zoneid=28543&popunder=1&toolbars=1&location=1&menubar=1&status=1&direct=1&resizable=1&scrollbars=1'></script>
</div>
</div>
</body>
</html>
