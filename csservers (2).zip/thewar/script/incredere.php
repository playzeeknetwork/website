<?php

                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TheWar.ro - Licente Steam Counter Strike 1.6, Counter Strike Source si alte jocuri!</title>
<style type="text/css">
@import url(http://thewar.ro/css.css);
</style>
<script type="text/javascript"></script><link rel='stylesheet' type='text/css' href='/B1D671CF-E532-4481-99AA-19F420D90332/netdefender/hui/ndhui.css' /></head>
<body>
    <div id="wrapper">
    <center><img src="images/logo.png" /></center>
    <ul id="nav">
        <li><a href="index.php">Prima pagina</a></li>
        <li><a href="desprejoc.php">Despre joc</a></li>
        <li><a href="premii.php">Premii</a></li>
        <li><a href="castigatori.php">Castigatori</a></li>
        <li><a href="concurenti.php">Concurenti</a></li>
        <li><a href="inregistrare.php">Inregistrare</a></li>
        <li><a href="cont.php">Contul meu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div id="content"> 
<center>
<blink><font color='red'>Aboneaza-te</font> <font color=yellow>acum pe <a href='http://www.zambete.net'><font color=green>Zambete.NET</font></a> si primesti +30 scor in concurs!<br /></blink>Nu uita sa iti folosesti adresa de email din contul tau!</font><Br /><Br /><script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar Ads 1 */
google_ad_slot = "1832938061";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>   	
        <h2><center>TheWar.ro Nu este teapa!</center></h2>
        <p><center>Ma bucur ca ai accesat aceasta pagina!<br />
	    De mult timp se tot zice ca jocul TheWar.ro este o mare teapa si ca nu merita sa jucati la noi. Cine zice aceste lucruri?<br />
        Jucatorii care au incercat sa triseze in jocul nostru dar care nu au avut prea mari reusite sau jucatorii care pur si simplu nu vor sa ne dea o sansa.<br />
        TheWar.ro nu este teapa! TheWar.ro acorda premii jucatorilor care au incredere in noi si joaca corect.<Br /><br />
        Dupa ce TheWar.ro s-a deschis, au inceput sa apara mai multe concursuri online cu premii ca si pe TheWar.ro dar care sau dovedit a fi teapa.<Br />Acest lucru nu inseamna ca si TheWar.ro este teapa!<br />Noi am venit primii cu aceasta idee si avem dovezi clare ca jucatorii nostri isi vor primi licenta atunci cand vor atringe pragul de scor necesar.<Br /><br /><br />Intr-o zi am inceput sa cautam pe google discutii despre acest concurs.<br /> 
        Am vrut sa vedem parerea jucatorilor despre acest concurs si am vazut-o dar, am observat ca aveti o parere total gresita despre acest concurs.<br />
        Ce am gasit pe google:<Br />
        <font color='orange'>Jucator</font>: concursul nu este teapa dar iti sterg de doua sau de trei ori din scor ca sa nu castigi premiul repede si abea apoi iti primesti premiul.<br />
        <font color='red'>TheWar.ro</font>: Gresit! Am tot scris prin pagini ca din contul vostru se va sterge scorul invalid atunci cand va fi verificat pentru ca a atins pragul de scor necesar pentru premiu! Noi nu zicem ca jucatorul a incercat sa triseze dar, mai exista oameni prea generosi sau prea rai, care vor acorda mai mult scor intr-o singura zi doar ca voi sa aveti de suferit in acest concurs.<br />Noi, pentru binele jucatorilor, ne-am gandit, de dinainte sa deschidem concursul, la o solutie! Asa ca in loc de a acorda ban unui jucator cu scor invalid, mai bine stergem scorul invalid si lasam jucatorul sa continue sa joace in concursul nostru.<br /><Br />
        <font color='orange'>Jucator</font>: Stiu sigur ca am numai scor corect facut!<br />
        <font color='red'>TheWar.ro</font>: De unde sti acest lucru? Nu ai de unde sti cine s-a suparat pe tine si vrea sa te incurce in acest joc. Nu ai de unde sti la cine ajunge link-ul tau unic din acest concurs.
        <br /><br />
        <font color='orange'>Jucator</font>: De unde sa ne dea licentele ? Este fake clar!<br />
        <font color='red'>TheWar.ro</font>: Din profit..
        <br /><Br />
        Dovezi ca am acordat premii tuturor jucatorilor:
        <img src='http://www.imgz.ro/i/1349511515-5.png' width='850px'>
        <img src='http://www.imgz.ro/i/1349511515-4.png' width='850px'>
        <img src='http://www.imgz.ro/i/1349511515-3.png' width='850px'>
        <img src='http://www.imgz.ro/i/1349511515-2.png' width='850px'>
        <img src='http://www.imgz.ro/i/1349511515-1.png' width='850px'><Br /><Br />
        Aveti incredere in noi! Nu aveti ce sa pierdeti.
        Nu trebuie sa dati bani sau alte bunuri de valoare ca sa jucati la noi!
        Trebuie doar sa rugati prietenii sa va ajute in acest concurs.
        <Br /><Br />
        Daca aveti alte intrebari in legatura cu acest concurs, nu ezitati sa ne contactati.
      </center></p>
        <br /><center>
          <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fthewar.ro&amp;width=700&amp;height=290&amp;colorscheme=dark&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:700px; height:290px;" allowtransparency="true"></iframe>
        </center><br />
        <center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0145581883123345";
/* thewar */
google_ad_slot = "7066114169";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center>
    </div>
    <div id="foot"><br><center><script type="text/javascript" src="http://profitshare.emag.ro/get_ads.php?zone_id=112055"></script></center><br /><!--/ GTop.ro - (begin) v2.1/-->
<script type="text/javascript" language="javascript">
var site_id = 49092;
var gtopSiteIcon = 79;
var _gtUrl = (("https:" == document.location.protocol) ? "https://secure." : "http://fx.");
document.write(unescape("%3Cscript src='" + _gtUrl + "gtop.ro/js/gTOP.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--/ GTop.ro - (end) v2.1/--> <a href='http://www.gtasa.ro' target="_blank"><img src='parteneri/gtasa.jpg' /></a> <a href='http://www.hackernews.ro' target="_blank"><img src='parteneri/hackernews.jpg' /></a> <a href='http://www.imgz.ro' target="_blank"><img src='parteneri/imgz.jpg' /></a> <a href='http://www.romaniadescarca.ro' target="_blank"><img src='parteneri/romaniadescarca.jpg' /></a> <a href='http://www.rss-ro.com' target="_blank"><img src='parteneri/rss.jpg' /></a> <a href='http://www.zambete.net' target="_blank"><img src='parteneri/zambete.jpg' /></a><br />&copy TheWar.ro<br />

<!--/* Ad4Game Popunder Tag */-->

<script type='text/javascript' src='http://ads.ad4game.com/www/delivery/apu.php?n=&zoneid=28543&popunder=1&toolbars=1&location=1&menubar=1&status=1&direct=1&resizable=1&scrollbars=1'></script>
</div>
</div>
</body>
</html>
