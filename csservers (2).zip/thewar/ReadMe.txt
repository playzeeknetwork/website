Aceasta arhiva a fost descarcata de pe http://webscript.do.am.

WebScript.Do.Am - Este un site ce contine resurse pentru platformele DLE (Data Life Engine) , Joomla , 
WordPress , Drupal , uCoz , vBulletin , IPB (Invision Power Board) , SMF (Simple Machine Forum) phpBB3 , 
XenForo , Platforme pentru Retele Sociale (Ex : facebook) , Scripturi Trackere de torrente , scriptrui pentru 
Chat Online , platforme si scripturi necesare crearii unui magazin online , Resurse necesare crearii unui 
site pentru webhosting , diferite teme HTML , CSS , FLASH , Indexuri pentru diferite siteuri , Diferite 
Scripturi PHP (Ex: Script pentru Site de Filme Online , Script pentru Site de Muzica , Script pentru site de 
Image Upload) si multe alte scripturi!

Multumim ca ati descarcat de pe websiteul nostru! Va mai asteptam



Alte siteuri :

- http://romcoz.ucoz.ro - Teme si scripturi uCoz in limba Romana .
- http://urips.do.am - Teme si scripturi uCoz in limba Engleza .

