<?php

 /*----------------------------------------------------------------------------------------------------------\
 |                                                                                                            |
 |                      [ LIVE GAME SERVER LIST ] [ � RICHARD PERRY FROM GREYCUBE.COM ]                       |
 |                                                                                                            |
 |    Released under the terms and conditions of the GNU General Public License Version 3 (http://gnu.org)    |
 |                                                                                                            |
 |-------------------------------------------------------------------------------------------------------------
 |        [ EDITOR STYLE SETTINGS: LUCIDA CONSOLE, SIZE 10, TAB = 2 SPACES, BOLD GLOBALLY TURNED OFF ]        |
 \-----------------------------------------------------------------------------------------------------------*/

//------------------------------------------------------------------------------------------------------------+

  require "lgsl_class.php";

//------------------------------------------------------------------------------------------------------------+
// THIS ALLOWS YOU TO CONTROL THE FIELDS DISPLAYED AND THEIR ORDER

  $fields_show  = array("name", "score", "deaths", "team", "ping", "bot", "time"); // THESE FIELDS ARE ORDERED FIRST
  $fields_hide  = array("teamindex", "pid", "pbguid"); // THESE FIELDS ARE REMOVED
  $fields_other = TRUE; // FALSE WILL HIDE FIELDS NOT IN $fields_show

//------------------------------------------------------------------------------------------------------------+
// GET THE SERVER DETAILS AND PREPARE IT FOR DISPLAY

  $lookup = lgsl_lookup_id($_GET['s']);

  if (!$lookup)
  {
    $output .= "<div style='margin:auto; text-align:center'> {$lgsl_config['text']['mid']} </div>"; return;
  }

  $server = lgsl_query_cached($lookup['type'], $lookup['ip'], $lookup['c_port'], $lookup['q_port'], $lookup['s_port'], "sep");
  $fields = lgsl_sort_fields($server, $fields_show, $fields_hide, $fields_other);
  $server = lgsl_sort_players($server);
  $server = lgsl_sort_extras($server);
  $misc   = lgsl_server_misc($server);
  $server = lgsl_server_html($server);

//------------------------------------------------------------------------------------------------------------+


//------------------------------------------------------------------------------------------------------------+
// SHOW THE STANDARD INFO

  $output .= "

<div style='padding: 10px; margin: 0px 10px 10px 10px; background: #F6F8FA; border: 1px solid silver; padding-bottom: 25px;'>



	<table class='tabel_date'>
		<tr>
			<td align='center' style='padding: 10px;' valign='top'>
        <h1>{$server['b']['ip']}</h1>
        <h4>{$server['s']['players']} / {$server['s']['playersmax']}</h4>
				<h5>{$server['s']['map']}</h5>		
				<p><img src='{$misc['image_map']}' alt='Current Map' /></p>
											<span style='color: red;'><img alt='' src='{$misc['icon_status']}' title='{$misc['text_status']}' /></span>
										</td>		<table style='color: #333;'>
					<tr>
						<td colspan='2'>
						<h4>{$server['s']['name']}</h4>
						</td>
					</tr>
    		<tr>
						<td>
							<h4>Status:</h4>
						</td>
						<td>
						{$misc['text_status']}						</td>
					</tr>
					
					<tr>
						<td>
							<h4>Adresa:</h4>
						</td>
						<td>
						{$server['b']['ip']}						</td>
					</tr>

										<tr>
						<td>
							<h4>Port:</h4>
						</td>
						<td>
													{$server['b']['c_port']}
													</td>
					</tr>
										<tr>
						<td>
							<h4>Joc:</h4>
						</td>
						<td>
						{$server['s']['game']}
						</td>
					</tr>
					<tr>
						<td>
							<h4>Anticheat:</h4>
						</td>
						<td>
							Valve Anti Cheat						</td>
							<tr>
							<td>
		<h4>Jucatori:</h4>
						</td>
						<td>
							{$server['s']['players']} / {$server['s']['playersmax']}						</td>
					</tr>
					<tr>
		
    </tr>
  </table>";

//------------------------------------------------------------------------------------------------------------+



//------------------------------------------------------------------------------------------------------------+
// SHOW THE PLAYERS

  $output .= "
  <div style='margin:auto; overflow:auto; text-align:center; padding:10px'>";

  if (!$server['p'] || !is_array($server['p']))
  {
    $output .= "
    <table cellpadding='4' cellspacing='2' style='margin:auto'>
      <tr style='".lgsl_bg(FALSE)."'>
        <td> {$lgsl_config['text']['npi']} </td>
      </tr>
    </table>";
  }
  else
  {
    $output .= "
	<table class='tabel_date_server'>
      <tr style='".lgsl_bg(FALSE)."'>";

      foreach ($fields as $field)
      {
        $field = ucfirst($field);
        $output .= "
        <td> <b>{$field}</b> </td>";
      }

      $output .= "
      </tr>";

      foreach ($server['p'] as $player_key => $player)
      {
        $output .= "
        <tr style='".lgsl_bg()."'>";

        foreach ($fields as $field)
        {
          $output .= "<td> {$player[$field]} </td>";
        }

        $output .= "
        </tr>";
      }

    $output .= "
    </table>";
  }

  $output .= "
  </div>";


?>
