<div style="padding: 10px; margin: 0px 10px 10px 10px; background: #F6F8FA; border: 1px solid silver; padding-bottom: 25px;">

<h1>Download</h1>

<h5>Sistemul tau de operare este <font color="#2DE0AE">Windows XP</font></h5>

	<table border="0" cellpadding="6" cellspacing="1" class="tabel_download">
		<tr>
			<th>NUME PRODUS</th>
			<th>DOWNLOAD</th>
			<th>INSTALARE/FOLOSIRE</th>
			<th>OPTIUNI</th>
			<th>SISTEM DE OPERARE NECESAR</th>
			<th>ULTIMUL UPDATE</th>
		</tr>
			<tr>
			<td>
				REDIRECTE CLASICE			</td>
			<td>
										<a href="http://www.csservers.ro/csservers_redirecte_windows_hlds.rar">csservers_redirecte_windows_hlds.rar</a>
									</td>
			<td align="center">
				<a href="www.csservers.ro">
					<a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-windows-hlds">TUTORIAL</a>
				</a>
			</td>
			<td style="width: 180px;">
				64 redirecte + 1 port 27015			</td>
			<td>
				<img src="http://www.csservers.ro/images/site/windows.png" width="20" align="absmiddle" />
				Windows (NT,XP,Vista,7)			</td>
			<td align="center">2012-11-03</td>
		</tr>
				<tr>
			<td>
				MASTER SERVER			</td>
			<td>
										<a href="http://www.csservers.ro/master_server.rar">master_server.rar</a>
									</td>
			<td align="center">
				<a href="www.csservers.ro">
					<a href="http://www.csservers.ro/tehnic/instalare-folosire-master-server">TUTORIAL</a>
				</a>
			</td>
			<td style="width: 180px;">
				LISTA servere Counter Strike Romania fara redirecte			</td>
			<td>
				<img src="http://www.csservers.ro/images/site/windows.png" width="20" align="absmiddle" />
				Windows (NT,XP,Vista,7)			</td>
			<td align="center">2012-09-29</td>
		</tr>
				<tr>
			<td>
				REDIRECTE CLASICE			</td>
			<td>
										wget www.csservers.ro/csservers_redirecte_linux_hlds.tar.gz									</td>
			<td align="center">
				<a href="www.csservers.ro">
					<a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-linux-hlds">TUTORIAL</a>
				</a>
			</td>
			<td style="width: 180px;">
				15 redirecte + 1 port 27015			</td>
			<td>
				<img src="http://www.csservers.ro/images/site/linux.png" width="20" align="absmiddle" />
				Linux (Orice distributie)			</td>
			<td align="center">2012-09-25</td>
		</tr>
			</table>
	</div>
