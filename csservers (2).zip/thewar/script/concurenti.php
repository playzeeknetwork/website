<?php

                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          
?>


 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TheWar.ro - Licente Steam Counter Strike 1.6, Counter Strike Source si alte jocuri!</title>
<style type="text/css">
@import url(http://thewar.ro/css.css);
</style>
<script type="text/javascript"></script><link rel='stylesheet' type='text/css' href='/B1D671CF-E532-4481-99AA-19F420D90332/netdefender/hui/ndhui.css' /></head>
<body>
    <div id="wrapper">
    <center><img src="images/logo.png" /></center>
    <ul id="nav">
        <li><a href="index.php">Prima pagina</a></li>
        <li><a href="desprejoc.php">Despre joc</a></li>
        <li><a href="premii.php">Premii</a></li>
        <li><a href="castigatori.php">Castigatori</a></li>
        <li><a href="concurenti.php">Concurenti</a></li>
        <li><a href="inregistrare.php">Inregistrare</a></li>
        <li><a href="cont.php">Contul meu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div id="content">
<center>
<blink><font color='red'>Aboneaza-te</font> <font color=yellow>acum pe <a href='http://www.zambete.net'><font color=green>Zambete.NET</font></a> si primesti +30 scor in concurs!<br /></blink>Nu uita sa iti folosesti adresa de email din contul tau!</font><Br /><Br /><script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar Ads 1 */
google_ad_slot = "1832938061";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>
        <h2><center>Concurenti</center></h2>
        <Center>
        <table id="rtable" sytle="width:100%">
            <tr><th>Rank</th><th>Nume</th><th>Scor</th><th>Premiu</th></tr>
            
            
            <?php

// Conectare MySQL
require ('config.php');
// -------------------

// Variabile

if(!isset($_GET['page'])){
    $page = 1;
} else {
    $page = $_GET['page'];
}

if (is_numeric ($page) && $page >= 1 && $page <= 9999 ) {

$max_results = 50;


$query = "SELECT status, COUNT(username) FROM users";
$result1 = mysql_query($query) or die(mysql_error());
while($row = mysql_fetch_array($result1)){
  $total_users = $row['COUNT(username)'];

}

$total_pages = ceil($total_users / $max_results);
$from = (($page * $max_results) - $max_results);




$sql = mysql_query("SELECT * FROM users order by id ASC LIMIT $from, $max_results ");
$num=1;
while($row = mysql_fetch_array($sql)){
    // Build your formatted results here.
$num++;

if(($num%2)!=0){
$bg="";
}else{
$bg="";
}

  $post = substr($row[5],0,40);

  $id = $row['id'];
  $username = $row['username'];
 // $email = $row['email'];
  $frags = $row['frags'];
  $premiu = $row['premiu'];
  $totalusers = count($username);
  print("<tr><td class='id100'>$id</td><td class='username101'>$username</td><td class='frags100'>$frags</td><td class='date100'>$premiu</td></tr>");
  }
print("</table>");
print("Concurenti: $total_users <br>");
// Page Links


if($page > 1){
    $prev = ($page - 1);
    echo "<a class=\"menu_link\" href=\"".$_SERVER['PHP_SELF']."?page=$prev\" ><<</a> ";
}

for($i = 1; $i <= $total_pages; $i++){
    if(($page) == $i){
        echo "$i ";
        } else {
            echo "<a href=\"".$_SERVER['PHP_SELF']."?page=$i\" class=\"menu_link\">[$i]</a> ";
    }
}

// Build Next Link
if($page < $total_pages){
    $next = ($page + 1);
    echo "<a href=\"".$_SERVER['PHP_SELF']."?page=$next\" class=\"menu_link\">>></a>";
}

}

else

{ print("Pagina ceruta nu exista !");}

?>

            
            
            
            </table>
           </center>        </Center><br /><br />
        <center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0145581883123345";
/* thewar */
google_ad_slot = "7066114169";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center>
    </div>
    <div id="foot"><br><center><script type="text/javascript" src="http://profitshare.emag.ro/get_ads.php?zone_id=112055"></script></center><br /><!--/ GTop.ro - (begin) v2.1/-->
<script type="text/javascript" language="javascript">
var site_id = 49092;
var gtopSiteIcon = 79;
var _gtUrl = (("https:" == document.location.protocol) ? "https://secure." : "http://fx.");
document.write(unescape("%3Cscript src='" + _gtUrl + "gtop.ro/js/gTOP.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--/ GTop.ro - (end) v2.1/--> <a href='http://www.gtasa.ro' target="_blank"><img src='parteneri/gtasa.jpg' /></a> <a href='http://www.hackernews.ro' target="_blank"><img src='parteneri/hackernews.jpg' /></a> <a href='http://www.imgz.ro' target="_blank"><img src='parteneri/imgz.jpg' /></a> <a href='http://www.romaniadescarca.ro' target="_blank"><img src='parteneri/romaniadescarca.jpg' /></a> <a href='http://www.rss-ro.com' target="_blank"><img src='parteneri/rss.jpg' /></a> <a href='http://www.zambete.net' target="_blank"><img src='parteneri/zambete.jpg' /></a><br />&copy TheWar.ro<br />

<!--/* Ad4Game Popunder Tag */-->

<script type='text/javascript' src='http://ads.ad4game.com/www/delivery/apu.php?n=&zoneid=28543&popunder=1&toolbars=1&location=1&menubar=1&status=1&direct=1&resizable=1&scrollbars=1'></script>
</div>
</div>
</body>
</html>
