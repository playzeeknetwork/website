function cauta_jucator_now(event,obj)
{
	if(event.keyCode=="13")
	{
		document.location='http://www.csservers.ro/jucator/'+obj.value;
	}
}

function cauta_jucator()
{
	var nume = document.getElementById('nume_jucator').value;
	document.location='http://www.csservers.ro/jucator/'+nume;
}

function _filtreaza(event)
{
	var path		= "";
	var server		= document.getElementById('server');
	var harta		= document.getElementById('harta');
	var mod			= document.getElementById('mod');

	if(trim(server.value)!="server")
	{
		server.style.color='black';
		server.style.fontStyle='normal';
	}
	else
	{
		server.style.color='#666';
		server.style.fontStyle='italic';
	}

	if(trim(harta.value)!="harta")
	{
		harta.style.color='black';
		harta.style.fontStyle='normal';
	}
	else
	{
		harta.style.color='#666';
		harta.style.fontStyle='italic';
	}
	
	if(trim(server.value)!="" && server.value!="server")				path+="/server/"+server.value;
	if(trim(harta.value)!="" && harta.value!="harta")					path+="/harta/"+harta.value;
	if(trim(mod.value)!="" && mod.value!="mod" && mod.value!="Toate")	path+="/mod/"+mod.value;
	
	if(event.keyCode==13 || event=="direct")
	{
		document.location = 'http://www.csservers.ro/f'+path+'/';
		return false;
	}
}

function _filtreaza_onfocus(obj)
{
	if(trim(obj.value)==obj.id)
		obj.value='';
}

function _filtreaza_onblur(obj)
{
	if(trim(obj.value)=='')
		obj.value=obj.id;
}

function trim(str)
{
   return str.replace(/^\s+|\s+$/g,'');
}

function incarcare_pagina(pagina,element)
{
	var x= Math.round(99999*Math.random());
	url=pagina+"?_x_y_z_="+x;

	var ajaxRequest;
	try
	{
		ajaxRequest = new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try
			{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert('You don`t have Ajax suport! , change browser pls!');
				return false;
			}
		}
	}
	
	if(element)
	{
		ajaxRequest.onreadystatechange=function()
		{
			if(ajaxRequest.readyState==4)
			{
				var content=ajaxRequest.responseText;
				document.getElementById(element).innerHTML=content;
			}
		}
	}

	ajaxRequest.open("GET",url,true);
	ajaxRequest.send(null);
}

function ruleaza_fisier(pagina)
{
	var x= Math.round(99999*Math.random());
	var da;
	url=pagina+"&_x_y_z_="+x;

	var ajaxRequest;
	try
	{
		ajaxRequest = new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try
			{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert('You don`t have Ajax suport! , change browser pls!');
				return false;
			}
		}
	}

	ajaxRequest.onreadystatechange=function()
	{
		if(ajaxRequest.readyState==4)
		{
			var content=ajaxRequest.responseText;	
		}
	}

	ajaxRequest.open("GET",url,true);
	ajaxRequest.send(null);
}

function ajaxLoad(pagina,element)
{
	var x= Math.round(99999*Math.random());
	url=pagina+"&_x_y_z_="+x;

	document.getElementById('element_redirecte').innerHTML='<br /><h3>Se creaza redirectele</h3><br /><img align="center" src="http://www.csservers.ro/images/site/loader.gif" /><br /><br />NU INTRERUPETI PROCESUL!';

	var ajaxRequest;
	try
	{
		ajaxRequest = new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try
			{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert('You don`t have Ajax suport! , change browser pls!');
				return false;
			}
		}
	}
	
	if(element)
	{
		ajaxRequest.onreadystatechange=function()
		{
			if(ajaxRequest.readyState==4)
			{
				var content=ajaxRequest.responseText;
				document.getElementById(element).innerHTML=content;
			}
		}
	}

	ajaxRequest.open("GET",url,true);
	ajaxRequest.send(null);
}

function inserare_jucator_red(dns)
{
	var x= Math.round(99999*Math.random());
	url='http://www.csservers.ro/pages/ajax.php?pag=insert_red&dns='+dns+"&_x_y_z_="+x;

	var ajaxRequest;
	try
	{
		ajaxRequest = new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try
			{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert('You don`t have Ajax suport! , change browser pls!');
				return false;
			}
		}
	}
	
	ajaxRequest.onreadystatechange=function()
	{
		if(ajaxRequest.readyState==4)
		{
			var content=ajaxRequest.responseText;
			document.getElementById('gigi').innerHTML=content;
		}
	}


	ajaxRequest.open("GET",url,true);
	ajaxRequest.send(null);

}

function conecteaza_acum(dns)
{
	window.location='steam://connect/'+dns;
}


/* consolikes!!! :D */

var server_mod		= "";
var lista_servere	= "";

function incarca_continut_fisier(variabila,fisier)
{
	var ajaxRequest;
	try
	{
		ajaxRequest = new XMLHttpRequest();
	}
	catch(e)
	{
		try
		{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		}
		catch(e)
		{
			try
			{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e)
			{
				alert('You don`t have Ajax suport! , change browser pls!');
				return false;
			}
		}
	}
	
	ajaxRequest.onreadystatechange=function()
	{
		if(ajaxRequest.readyState==4)
		{
			switch(variabila)
			{
				case 'server_mod':
					server_mod = ajaxRequest.responseText;
					break;
				case 'lista_servere':
					lista_servere = ajaxRequest.responseText;
					break;
			}
		}
	}
	
	ajaxRequest.open("GET",'/pages/consola/'+fisier,true);
	ajaxRequest.send(null);
}

function input(event)
{
	var consola_input = document.getElementById('consola_input');

	if(event.keyCode==38)
	{	
		consola_input.value=document.getElementById('ultima_comanda').value;
		consola_input.focus();
	}
	if(event.keyCode==40)
	{
		consola_input.value='';
		consola_input.focus();
	}
	if(event.keyCode==192)
	{
		// as vrea sa sterg continutul ei daca apasa ` da nu prea merge nici asa :(
		consola_input.value='';
	}
	if(event.keyCode==13)
	{
		shell(consola_input.value);
	}
}

function shell(comanda)
{
	if(!comanda) return false;
	document.getElementById('ultima_comanda').value=comanda;
	if(comanda.indexOf(" ",0)==-1) // inseamna ca avem spatiu 
	{
		switch (comanda)
		{
			case 'help':
				output("help","<br />Comenzi disponibile: <br /> <br /> add_server [dns] ["+trim(server_mod)+"]");
				break;
			case 'add_server':
				output("add_server","<br />Pentru a adauga un server sintaxa este: <br /><br />add_server [dns] mod ["+trim(server_mod)+"]");
				break;
			case 'add_server help':
				output("add_server help","<br />Pentru a adauga un server sintaxa este: add_server [dns] mod ["+trim(server_mod)+"]");
				break;
			default:
				output(comanda,"<br />Comanda invalida sau sintaxa gresita , scrie [help] pentru lista de comenzi disponibile");
		}
	}
	else
	{
		comanda2 = comanda;
		comanda_compusa = comanda2.split(" ");
		
		if(comanda_compusa[0]=="add_server" && comanda_compusa.length==3)
		{
			add_server_server = comanda_compusa[1].toLowerCase();

			if(lista_servere.indexOf(add_server_server)==-1)
			{
				var regex = /[0-9-\.a-z]+/i;

				if(add_server_server.match(regex)==add_server_server)
				{
					if(server_mod.indexOf(comanda_compusa[2])==-1)
					{
						output(comanda,"<br />EROARE! Modul "+comanda_compusa[2]+" nu se afla in baza de date");
					}
					else
					{
						ruleaza_fisier("/pages/consola/adauga_server.php?nume_server="+add_server_server+"&mod="+comanda_compusa[2]);
						if(trim(status_server_adaugat)=="FAIL")
						{
							output(comanda,"<br />Serverul nu poate fi scanat sau este OFFLINE! <br /> "+add_server_server+" NU a fost adaugat in baza de date!");
						}
						else
						{
							output(comanda,"<hr />Serverul: "+comanda_compusa[1]+"<br /> mod: "+comanda_compusa[2]+"<hr /> A fost adaugat in baza date si urmeaza a fi scanat! <br /> Va rugam sa va asigurati ca serverul este ON! <br /> La 99 de scanari cu rezultat OFFLINE el este automat sters din baza de date!");
							incarca_continut_fisier("lista_servere","verificare_lista_servere.php");
						}
					}
					
				}
				else
				{
					output(comanda,'<br />Numele serverului este invalid');
				}
			}
			else
			{
				output(comanda,'<br />Serverul '+comanda_compusa[1]+' exista deja in baza de date!');
			}
		}
		else
		{
			output(comanda,'Comanda invalida sau sintaxa gresita , scrie [help] pentru lista de comenzi disponibile');
		}
	}
	document.getElementById('consola_input').value='';
}

function output(input,display)
{
	var consola_output = document.getElementById('consola_output');
	var input_nou = "";

	consola_output.innerHTML = "<br />input: "+removeHTMLTags(input)+"<br />"+display;
}

function consola(event)
{
	if(event.keyCode==192)
	{
		// luam continutul fisierelor care ne trebuie pt validare
		if(server_mod=="") incarca_continut_fisier("server_mod","verificare_moduri_servere.php");
		if(lista_servere=="") incarca_continut_fisier("lista_servere","verificare_lista_servere.php");

		if(document.getElementById('consola'))
		{
			consola = document.getElementById('consola');
			document.body.removeChild(consola);
		}
		else
		{
			//creem elementele
			var consola = document.createElement('table');
				consola.setAttribute('id','consola');
				consola.setAttribute('border','1');
				consola.setAttribute('cellspacing','0');
				consola.setAttribute('cellpadding','0');
			
			var tr1 = document.createElement('tr');
			var tr2 = document.createElement('tr');
			var td2 = document.createElement('td');
				td2.style.height='1px';
				td2.style.padding='1px';
				td2.style.overflow='hidden';
			
			var consola_input = document.createElement('input');
				consola_input.setAttribute('id','consola_input');
				consola_input.setAttribute('onkeydown','input(event)');
			
			var consola_output = document.createElement('td');
				consola_output.setAttribute('id','consola_output');
				consola_output.innerHTML = 'Consola versiunea 1.0 creata de Master Computer pentru csservers.ro <br /> Toate drepturile rezervate <br /> Scrie "help" pentru comenzile disponibile <br /><br />';
			
			var ultima_comanda = document.createElement('input');
				ultima_comanda.setAttribute('type','hidden');
				ultima_comanda.setAttribute('id','ultima_comanda');

			//lipim elementele
			document.body.appendChild(consola);
			consola.appendChild(tr1);
			tr1.appendChild(consola_output);
			tr1.appendChild(ultima_comanda);

			consola.appendChild(tr2);
			tr2.appendChild(td2);
			td2.appendChild(consola_input);


			// aplicam CSS la elemente
			with(document.getElementById('consola'))
			{
				style.background="#4C5844";
				style.position="absolute";
				style.top="0px";
				style.fontSize="11px";
				style.fontFamily="Verdana";
				style.padding="4px";
				style.height="50%";
				style.width="90%";
				style.marginLeft='30px';
			}

			with(document.getElementById('consola_input'))
			{
				style.width="100%";

				style.background="#3E4637";
				style.color="#CCC";
				style.fontFamily='Terminal';
				style.padding='4px';
				style.border='transparent';
				focus();
			}

			with(document.getElementById('consola_output'))
			{
				style.background="#3E4637";
				style.overflow='hidden';
				style.color="#CCC";
				style.height='100%';
				style.fontFamily='Terminal';
				style.fontSize='12px';
				style.verticalAlign='bottom';
				style.padding='8px';
			}
		}
	}
}

function removeHTMLTags(strInputCode)
{
	strInputCode = strInputCode.replace(/&(lt|gt);/g, function (strMatch, p1){
	return (p1 == "lt")? "<" : ">";
	});
	var strTagStrippedText = strInputCode.replace(/<\/?[^>]+(>|$)/g, "");
	return strTagStrippedText;	
}