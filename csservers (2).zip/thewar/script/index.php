<?php

                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TheWar.ro - Licente Steam Counter Strike 1.6, Counter Strike Source si alte jocuri!</title>
<style type="text/css">
@import url(http://thewar.ro/css.css);
</style>
<script type="text/javascript"></script><link rel='stylesheet' type='text/css' href='/B1D671CF-E532-4481-99AA-19F420D90332/netdefender/hui/ndhui.css' /></head>
<body>
    <div id="wrapper">
    <center><img src="images/logo.png" /></center>
    <ul id="nav">
        <li><a href="index.php">Prima pagina</a></li>
        <li><a href="desprejoc.php">Despre joc</a></li>
        <li><a href="premii.php">Premii</a></li>
        <li><a href="castigatori.php">Castigatori</a></li>
        <li><a href="concurenti.php">Concurenti</a></li>
        <li><a href="inregistrare.php">Inregistrare</a></li>
        <li><a href="cont.php">Contul meu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div id="content"> 
<center>
<blink><font color='red'>Aboneaza-te</font> <font color=yellow>acum pe <a href='http://www.zambete.net'><font color=green>Zambete.NET</font></a> si primesti +30 scor in concurs!<br /></blink>Nu uita sa iti folosesti adresa de email din contul tau!</font><Br /><Br /><script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar Ads 1 */
google_ad_slot = "1832938061";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>   	
        <h2><center>Concurs Online</center></h2>
        <p><center>TheWar.ro este un concurs online la care poti castiga foarte usor o licenta la unul din jocurile tale preferate!<br />
	    Jocul este destul de simplu. Nu trebuie decat sa va inregistrati si sa faceti cat mai multa lume sa va ajute in acest joc. <a href='desprejoc.php'><font color='green'>Aflati mai multe aici.</font></a></center></p><br />
	    <p><center><font color='red'><strong>De ce sa aveti incredere in noi?</strong></font></center>
        <center>Avem <a href='castigatori.php' target='_blank'><font color='green'>34 castigatori</font></a> din editia trecuta, fiecare fiind multumit de premiul castigat fara sa primim vreo reclamatie si <a href='http://facebook.com/thewar.ro' target='_blank'><font color='green'>avem peste 6500 Like-uri pe FaceBook</font></a> fara sa rugam jucatorii sa dea Like!</center></p>
        <p><center>Intra si tu in razboi ca sa castigi o licenta la unul din jocurile tale preferate!<br /><a href='inregistrare.php'><img src='images/inregistrare.png' /></a></center></p><br />
        <p><center><font color='green'><strong><blink>Atentie!</blink></strong></font> Concursul nu este unul cu mai multe sezoane!<br>Puncetele nu ti se vor sterge decat dupa ce ai castigat premiul sau dupa ce au fost gasite voturi invalide in contul tau.</font></center></p>
        <br /><center><iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2Fthewar.ro&amp;width=700&amp;height=290&amp;colorscheme=dark&amp;show_faces=true&amp;border_color&amp;stream=false&amp;header=true" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:700px; height:290px;" allowTransparency="true"></iframe></center><br />
        <center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
<script type="text/javascript"><!--
google_ad_client = "ca-pub-0145581883123345";
/* thewar */
google_ad_slot = "7066114169";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center>
    </div>
    <div id="foot"><br><center><script type="text/javascript" src="http://profitshare.emag.ro/get_ads.php?zone_id=112055"></script></center><br /><!--/ GTop.ro - (begin) v2.1/-->
<script type="text/javascript" language="javascript">
var site_id = 49092;
var gtopSiteIcon = 79;
var _gtUrl = (("https:" == document.location.protocol) ? "https://secure." : "http://fx.");
document.write(unescape("%3Cscript src='" + _gtUrl + "gtop.ro/js/gTOP.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--/ GTop.ro - (end) v2.1/--> <a href='http://www.gtasa.ro' target="_blank"><img src='parteneri/gtasa.jpg' /></a> <a href='http://www.hackernews.ro' target="_blank"><img src='parteneri/hackernews.jpg' /></a> <a href='http://www.imgz.ro' target="_blank"><img src='parteneri/imgz.jpg' /></a> <a href='http://www.romaniadescarca.ro' target="_blank"><img src='parteneri/romaniadescarca.jpg' /></a> <a href='http://www.rss-ro.com' target="_blank"><img src='parteneri/rss.jpg' /></a> <a href='http://www.zambete.net' target="_blank"><img src='parteneri/zambete.jpg' /></a><br />&copy TheWar.ro<br />

<!--/* Ad4Game Popunder Tag */-->

<script type='text/javascript' src='http://ads.ad4game.com/www/delivery/apu.php?n=&zoneid=28543&popunder=1&toolbars=1&location=1&menubar=1&status=1&direct=1&resizable=1&scrollbars=1'></script>
</div>
</div>
</body>
</html>
