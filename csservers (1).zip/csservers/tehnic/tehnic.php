
<h1>Tehnic</h1>
<ol>
<li><a href="http://www.csservers.ro/tehnic/instalare-folosire-master-server">Instalare/folosire Master-Server</a></li>
<li><a href="http://www.csservers.ro/tehnic/cum-sa-apari-la-internet">Reguli de baza pentru a folosi redirectele WINDOWS</a></li>
<li><a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-windows-hlds">Instalare/folosire redirecte windows_hlds</a></li>
<li><a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-linux-hlds">Instalare/folosire redirecte linux_hlds</a></li>
<!-- <li><a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-linux-2.2">Instalare/folosire redirecte linux_2.2</a></li>
<li><a href="http://www.csservers.ro/tehnic/instalare-folosire-redirecte-linux-2.1">Instalare/folosire redirecte linux_2.1</a></li> -->
<li><a href="http://www.csservers.ro/tehnic/cum-sa-pornesti-redirectele-pe-64-biti">Cum sa pornesti redirectele pe 64 biti</a></li>
</ol>
