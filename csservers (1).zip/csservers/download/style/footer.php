<div class="meniu_jos">
<p>
			<span style="font-size:13px;"><a href="http://www.csservers.ro/info">info</a>&nbsp;| <a href="http://www.csservers.ro">lista servere</a>&nbsp;| <a href="http://www.csservers.ro/adauga-server">adauga server</a>&nbsp;| <a href="http://www.csservers.ro/download">download</a>&nbsp;| <a href="http://www.csservers.ro/castiga-dropuri">castiga dropuri</a>&nbsp;| <a href="http://www.csservers.ro/tehnic">tehnic</a>&nbsp;| <a href="http://www.csservers.ro/evidenta-live">evidenta redirectelor live</a>&nbsp;| <a href="http://www.csservers.ro/cumpara-componente">cumpara componente</a>&nbsp;| <a href="http://www.csservers.ro/webhosting-gratuit">webhosting gratuit</a>&nbsp;| <a href="http://www.csservers.ro/contact">contact</a></span></p></div>

<div class="footer">

<p><span style="font-size:13px;">Copyright &copy; 2011-2012 www.csservers.ro. | Modifications by hadesownage and Mr.Crazy All rights reserved.</p></span>

<!-- T5 Codes -->
<span id="t5_zone_standard-ga"></span>
<script type="text/javascript">
var t5_wid='34458341';
var t5_badge='standard-ga';
</script>
<script type="text/javascript" src="http://www.t5.ro/static/t5-stats.js"></script>
<!-- T5 Codes -->
