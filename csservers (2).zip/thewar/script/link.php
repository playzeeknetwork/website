<?php

                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          
?>


<div align="center">
  <p>
  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TheWar.ro - Licente Steam Counter Strike 1.6, Counter Strike Source si alte jocuri!</title>
<style type="text/css">
@import url(http://thewar.ro/css.css);
</style>
<script type="text/javascript"></script><link rel='stylesheet' type='text/css' href='/B1D671CF-E532-4481-99AA-19F420D90332/netdefender/hui/ndhui.css' /></head>
<body>
    <div id="wrapper">
    <center><img src="images/logo.png" /></center>
    <ul id="nav">
        <li><a href="index.php">Prima pagina</a></li>
        <li><a href="desprejoc.php">Despre joc</a></li>
        <li><a href="premii.php">Premii</a></li>
        <li><a href="castigatori.php">Castigatori</a></li>
        <li><a href="concurenti.php">Concurenti</a></li>
        <li><a href="inregistrare.php">Inregistrare</a></li>
        <li><a href="cont.php">Contul meu</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
    <div id="content"> 
<center>
<blink><font color='red'>Aboneaza-te</font> <font color=yellow>acum pe <a href='http://www.zambete.net'><font color=green>Zambete.NET</font></a> si primesti +30 scor in concurs!<br /></blink>Nu uita sa iti folosesti adresa de email din contul tau!</font><Br /><Br /><script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar Ads 1 */
google_ad_slot = "1832938061";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>   
  <?php

  if(isset($_GET['player'])){
  
  //print_r($_GET['player']);
    
     //$jucator = mysql_real_escape_string(htmlentities($_GET['player']));
     
     $form = " <p><center><font color=green size=4>Apasa clic pe <font color=red>soldat</font> pentru a il ajuta pe <font color=yellow>".$_GET['player']."</font> sa castige +1 scor!</font></center></p>
                <p>
   <table><tr>
     <td><a href='take_frag_error.php' title='Ostatic' class='ho2'>Ostatic</a></td>
     <td><a href='take_frag.php' title='Soldat German' class='nazi'>Soldat German</a></td>
     <td><a href='take_frag_error.php' title='Ostatic' class='ho1'>Ostatic</a></td>
     </tr></table>    ";
     
     print $form;
     
  } else {
   
   print 'Se pare ca nu exista acest player.';

  }
?>
  
  <center><script type="text/javascript"><!--//<![CDATA[
var lm_r = Math.floor(Math.random()*99999999999);
document.write ("<ifr"+"ame marginheight='0' marginwidth='0' scrolling='no' frameborder='0' width='468' height='60' target='_blank' src='"+lm_u+"'><\/ifr"+"ame>");
//]]>--></script></center>
 <br>
   </font></p>
</div>

    <br /><br />
        <center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
<script type="text/javascript"><!--
google_ad_client = "ca-pub-6038979446974625";
/* TheWar.ro Ads 2 */
google_ad_slot = "8452560666";
google_ad_width = 336;
google_ad_height = 280;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script></center></div>
    <div id="foot"><br><center><script type="text/javascript" src="http://profitshare.emag.ro/get_ads.php?zone_id=112055"></script></center><br /><!--/ GTop.ro - (begin) v2.1/-->
<script type="text/javascript" language="javascript">
var site_id = 49092;
var gtopSiteIcon = 79;
var _gtUrl = (("https:" == document.location.protocol) ? "https://secure." : "http://fx.");
document.write(unescape("%3Cscript src='" + _gtUrl + "gtop.ro/js/gTOP.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<!--/ GTop.ro - (end) v2.1/--> <a href='http://www.gtasa.ro' target="_blank"><img src='parteneri/gtasa.jpg' /></a> <a href='http://www.hackernews.ro' target="_blank"><img src='parteneri/hackernews.jpg' /></a> <a href='http://www.imgz.ro' target="_blank"><img src='parteneri/imgz.jpg' /></a> <a href='http://www.romaniadescarca.ro' target="_blank"><img src='parteneri/romaniadescarca.jpg' /></a> <a href='http://www.rss-ro.com' target="_blank"><img src='parteneri/rss.jpg' /></a> <a href='http://www.zambete.net' target="_blank"><img src='parteneri/zambete.jpg' /></a><br />&copy TheWar.ro<br />

<!--/* Ad4Game Popunder Tag */-->

<script type='text/javascript' src='http://ads.ad4game.com/www/delivery/apu.php?n=&zoneid=28543&popunder=1&toolbars=1&location=1&menubar=1&status=1&direct=1&resizable=1&scrollbars=1'></script>
</div>
</div>
</body>
</html>
