<td><a href="index.php" class="meniu_sus_inactiv">Home</a></td>
<td><a href="serverlist" class="meniu_sus_inactiv">Lista Servere</a></td>
<td><a href="?s=add" class="meniu_sus_inactiv">Adauga Servere</a></td>
<td><a href="download" class="meniu_sus_activ">Download</a></td>
<td><a href="#" class="meniu_sus_inactiv">Castiga dropuri</a></td>
<td><a href="#" class="meniu_sus_inactiv">Tehnic</a></td>
<td><a href="#" class="meniu_sus_inactiv">Evidenta redirectelor live</a></td>
<td><a href="#" class="meniu_sus_inactiv">Cumpara Componente</a></td>
<td><a href="#" class="meniu_sus_inactiv">Webhosting Gratuit</a></td>
<td><a href="#" class="meniu_sus_inactiv">Contact</a></td>