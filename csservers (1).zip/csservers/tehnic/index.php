
<?php
require('style/header.php');
require('style/meniu-tehnic.php');

?>

	</tr>
</table>

<br>
<div style="padding-left: 10px; padding-top: 5px;">
<a href="http://www.cs-boost.com" target="_blank"><img src="http://www.csservers.ro/images/site/banner_cs_boost.png" /></a>
</div>
<br>
<div style="padding: 10px; margin: 0px 10px 10px 10px; background: #F6F8FA; border: 1px solid silver; padding-bottom: 25px;">
<?php

require('tehnic.php');

?>

</div>

<?php

require('style/footer.php');

?>