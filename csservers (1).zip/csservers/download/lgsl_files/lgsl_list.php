<?php

 /*----------------------------------------------------------------------------------------------------------\
 |                                                                                                            |
 |                      [ LIVE GAME SERVER LIST ] [ � RICHARD PERRY FROM GREYCUBE.COM ]                       |
 |                                                                                                            |
 |    Released under the terms and conditions of the GNU General Public License Version 3 (http://gnu.org)    |
 |                                                                                                            |
 |-------------------------------------------------------------------------------------------------------------
 |        [ EDITOR STYLE SETTINGS: LUCIDA CONSOLE, SIZE 10, TAB = 2 SPACES, BOLD GLOBALLY TURNED OFF ]        |
 \-----------------------------------------------------------------------------------------------------------*/

//------------------------------------------------------------------------------------------------------------+

  require "lgsl_class.php";

  $server_list = lgsl_query_cached_all("s");
  $server_list = lgsl_sort_servers($server_list);

//------------------------------------------------------------------------------------------------------------+

  $output .= "
  <div style='text-align:center; font-size:10px; font-face:arial'>

<table class='tt' cellpadding='3' cellspacing='1' style='margin:auto' >
      <thead>
		<tr class='lgsl'>
				<th class='lgsl' style='width:113px;' title='Server Status'>[ Status ]</th>
				<th class='lgsl' style='width:15px;' title='Game'>[ G ]</th>
				<th class='lgsl' style='width:15px;' title='Country'>[ Tara ]</th>
				<th class='lgsl' style='width:200px;' title='Name Server'>[ Nume Server ]</th>
				<th class='lgsl' style='width:75px;' title='DnS'>[ DnS + Connect]</th>
				<th class='lgsl' style='width:95px;' title='Current Map'>[ Harta ]</th>
				<th class='lgsl' style='width:50px;' title='Players online'>[ Jucatori ]</th>

				
		</tr>
     </thead>";

    foreach ($server_list as $server)
    {
      $misc   = lgsl_server_misc($server);
      $server = lgsl_server_html($server);

      $output .= "
   <tr class='lgsl' style='table-layout:fixed'>

    <td class='lgsl'  style='white-space:nowrap; text-align:center'>
          <img alt='' src='{$misc['icon_status']}' title='{$misc['text_status']}' />
        </td>

        <td class='lgsl'   style='white-space:nowrap; text-align:center'>
          <img alt='' src='{$misc['icon_game']}' title='CS' />
        </td>
<td class='lgsl'  style='white-space:nowrap; text-align:center'>
		<img src='http://www.gametracker.com/images/flags/ro.gif' title='Tara' >
		</td>
		 <td class='lgsl' title='{$server['s']['name']}' style='text-align:left'>
          <div style='width:100%; overflow:hidden; height:1.3em'>
		 <b><a href='".lgsl_link($server['o']['id'])."'>{$server['s']['name']}</a></b>
          </div>
        </td>
        <td  class='lgsl' title='{$lgsl_config['text']['slk']}' style='text-align:center'>
     
<a href='steam://{$misc['software_link']}'  class='Tips1' title=' Connect {$server['b']['ip']}'>

            <b> {$server['b']['ip']} </b>
        </a> 
        </td>


        <td class='lgsl' style='white-space:nowrap; text-align:center'>
          <b><font color='#0d619b'>{$server['s']['map']}</font></b>
        </td>

        <td class='lgsl' style='white-space:nowrap; text-align:center'>
          <b><font color='#0d619b'> {$server['s']['players']} / {$server['s']['playersmax']} </font></b>
        </td>
        

        

      </tr>";
    }

    $output .= "
    </table>
  </div>";

//------------------------------------------------------------------------------------------------------------+ 
  if ($lgsl_config['list']['totals']) 
  { 
    $total = lgsl_group_totals($server_list); 

    $output .= " 
    <div> 
      <br /> 
    </div> 
    <div style='text-align:center'> 
      <table style='margin:auto' cellpadding='4' cellspacing='2'> 
        <tr style='".lgsl_bg()."'> 
          <td> {$lgsl_config['text']['tns']} {$total['servers']}    </td> 
          <td> {$lgsl_config['text']['tnp']} {$total['players']}    </td> 
          <td> {$lgsl_config['text']['tmp']} {$total['playersmax']} </td> 
        </tr> 
      </table> 
    </div>"; 
  } 
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+ 
//------  PLEASE MAKE A DONATION OR SIGN THE GUESTBOOK AT GREYCUBE.COM IF YOU REMOVE THIS CREDIT ---------------------------------------------------------------------------------------------------+
  $output .= "";
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+

?>
