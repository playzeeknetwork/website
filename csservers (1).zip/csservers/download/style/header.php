<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Redirecte Counter Strike</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="ro"/>
<meta name="google-site-verification" content="0UFEBEg_rqSmufrrfR81_dHCM5jz_WLrUINfYyacT10" />
<meta name="keywords" content="redirecte,cs,servere,evidenta" />
<meta name="description" content="Redirecte CS windows si linux pentru toate serverele din Romania" />
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" /> 
<link type="text/css" href="http://www.csservers.ro/_system/style.css" rel="stylesheet" />
<!-- <script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script> -->
<script type="text/javascript" src="_system/functions.js"></script>
<script type="text/javascript" src="_system/jscharts.js"></script>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17329196-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<link href="_system/datepicker/datepicker.css" rel="stylesheet" type="text/css" />
<script src="_system/datepicker/datepicker.js" type="text/javascript"></script>
</head>

<body>
<div style="background: url('images/site/background_sus.png'); border-bottom: 1px solid #2989BA; border-top: 1px solid #333333; padding-bottom: 5px;">
<table>
	<tr>
	<br>
	<br>
	<br>
		<td><a href="http://localhost/csservers/index.php"><img src="images/site//logo_csservers.ro.png" alt="CsCervers.ro" /></a></td>
		<!-- <td><g:plusone></g:plusone>			<br /><br />
		
			<div id="google_translate_element"></div>
			<script>
			function googleTranslateElementInit() {
			  new google.translate.TranslateElement({
				pageLanguage: 'ro',
				layout: google.translate.TranslateElement.InlineLayout.SIMPLE
			  }, 'google_translate_element');
			}
			</script><script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
		</td> -->
		<td><br>
			<ul class="statistici_sus">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</ul>
		</td>
		<td style="color: #333; padding-left: 10px; line-height: 27px;">
			<table>
				<tr>
					<td>

					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
<br>
</div>
<table cellpadding="0" cellspacing="0" class="meniu_sus">
	<tr>