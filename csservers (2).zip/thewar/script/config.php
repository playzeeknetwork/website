<?php



                          
//                                                                                          |__   __   __|  ___    __ 
//                                                                                          |  ) (__( (__| (__/_ __)  
                          



// Parametri SQL

$_mysql_host="localhost"; // Host baza de date
$_mysql_db="webscript"; // Baza de date
$_mysql_user="webscript"; // User baza de date
$_mysql_password="webscript"; // Parola baza de date
$siteurl = "localhost";
$conexiune = mysql_connect($_mysql_host,$_mysql_user,$_mysql_password) or die("a.Nu ma pot conecta la MySQL!");
mysql_select_db($_mysql_db, $conexiune) or die("Nu gasesc baza de date");
?>